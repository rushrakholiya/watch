jQuery(document).ready(function($) {
	$("div.b5_file_manager_theme_column input[type='checkbox']").tzCheckbox({labels:[b5_file_manager_tzchekbox.b5_file_manager_enable,b5_file_manager_tzchekbox.b5_file_manager_disable]});
});